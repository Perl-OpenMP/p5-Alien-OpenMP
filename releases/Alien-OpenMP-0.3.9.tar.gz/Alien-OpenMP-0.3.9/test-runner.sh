#!/usr/bin/env bash

TESTS=$@

if [ -z "$TESTS" ]; then
  TESTS=$(ls -1 ./t)
fi

rm -rf blib > /dev/null 2>&1
mkdir -p blib/lib/Alien/OpenMP

cp lib/Alien/OpenMP/configure.pm blib/lib/Alien/OpenMP/configure.pm
cp lib/Alien/OpenMP.pm blib/lib/Alien/OpenMP.pm

EXIT=0
for FILE in $TESTS; do
  PERL_DL_NONLAZY=1 perl -Ilib -MExtUtils::Command::MM -MTest::Harness -e "undef *Test::Harness::Switches; test_harness(1, 'blib/lib', 'blib/arch')" t/$FILE
  if [ $? != 0 ]; then
    EXIT=$(($EXIT+1))
  fi
done

exit $EXIT
